''''''
'''
Tasks:
-------------
1. Store 5 students information like sid,name, age, marks, school_name, gender using Data Structure
2. Store 10 states of country India 
3. Store 10 employee ids of a company 
4. Store marks of 10 students with their name and employee id.
5. Take any 3 random invoices(like current bill) and store all attributes using data structure

Questions:
--------------
1. Variables. Explain in detail 
2. Tokens in python 
3. Implicit casting vs Explicit casting 
4. Type promotion 
5. Explain about each function 
	print type id int float bool str list tuple dict set 
6. == vs is 
7. Difference between and or operators. Any two realtime examples 
8. Keywords in python 

'''