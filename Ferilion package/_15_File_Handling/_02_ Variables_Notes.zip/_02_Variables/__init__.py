''''''
'''
Entity: Employee:
======================
STATE:
------
Attributes: eid, name, sal, address, mobile, email, is_perm
Value     : 100, "Madhu Nettem", 15000, 'Bangalore', '3243243', 'email@oracle.com', True
Datatype  : int, str, float, str, str, str, bool 

int eid = 100  # Java
    eid = 100  # Python
Datatype attr = value  # Java
         attr = value  # Python 

BEHAVIOR (CRUD) :
------------------
1. CREATE an Employee 
2. RETRIEVE employee info
3. UPDATE mobileno,address,passwords
4. DELETE emailid, empid 


'''
