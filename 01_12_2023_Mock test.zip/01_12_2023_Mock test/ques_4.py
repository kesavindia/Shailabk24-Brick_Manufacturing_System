#convert nested list into single list in sorted order

nested_list = [[11,22,33],[43,25,36],[57,78,79]]
single_list = []
for i in nested_list:
    for j in i:
        single_list.append(j)
print("Single_list: ",single_list)
Ascending = sorted(single_list)
rev_sort =reversed(single_list)
print("In Ascending Order: ",Ascending)
rev_order = [i for i in rev_sort]
print("In descending Order: ",rev_order)

