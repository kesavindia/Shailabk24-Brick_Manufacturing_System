#contiguous subarray with maximum sum

list = [1,2,3,-5,6,3,-6,8,5,-2]

largest_sum = 0
current_sum = 0
for i in list:
    current_sum = max(list[i],(current_sum+list[i]))
    if current_sum > largest_sum:
        largest_sum = current_sum
    largest_sum = max(largest_sum,current_sum)
print(largest_sum)