#sort a list of tuple based on a specific index

tuple = (1,2,3,4,5,6,8,7)
sorted_tuple=()
max=-100000
for i in range(0,len(tuple)):
    if tuple[i] > max:
        max = tuple[i]
    sorted_tuple += max,
print(sorted_tuple)